<?php
	$server = "localhost";
	$dbuser = "root";
	$dbpass = "";
	$dbname = "cb";
?>